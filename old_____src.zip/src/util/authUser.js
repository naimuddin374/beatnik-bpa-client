import store from '../store';

const authUser = () => {
    const state = store.getState();
    if (!state.auth.isAuth) return false
    return state.auth.user[0]
}
export default authUser